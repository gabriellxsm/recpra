﻿namespace recuperaçao
{
    partial class tela_principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblusuario = new Label();
            datagridTarefas = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnInserir = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            txtID = new TextBox();
            txtNome = new TextBox();
            txtDescriçao = new TextBox();
            dtpData = new DateTimePicker();
            dtpHorario = new DateTimePicker();
            btnDeslogar = new Button();
            label6 = new Label();
            dateTimeFiltrar = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)datagridTarefas).BeginInit();
            SuspendLayout();
            // 
            // lblusuario
            // 
            lblusuario.AutoSize = true;
            lblusuario.Location = new Point(410, 9);
            lblusuario.Name = "lblusuario";
            lblusuario.Size = new Size(95, 18);
            lblusuario.TabIndex = 0;
            lblusuario.Text = "<<usuario>>";
            // 
            // datagridTarefas
            // 
            datagridTarefas.AllowUserToAddRows = false;
            datagridTarefas.AllowUserToDeleteRows = false;
            datagridTarefas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            datagridTarefas.Location = new Point(12, 94);
            datagridTarefas.Name = "datagridTarefas";
            datagridTarefas.ReadOnly = true;
            datagridTarefas.Size = new Size(899, 188);
            datagridTarefas.TabIndex = 1;
            datagridTarefas.CellDoubleClick += datagridTarefas_CellDoubleClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 70);
            label1.Name = "label1";
            label1.Size = new Size(27, 18);
            label1.TabIndex = 2;
            label1.Text = "ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(85, 303);
            label2.Name = "label2";
            label2.Size = new Size(54, 18);
            label2.TabIndex = 3;
            label2.Text = "Nome:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(85, 367);
            label3.Name = "label3";
            label3.Size = new Size(46, 18);
            label3.TabIndex = 4;
            label3.Text = "Data:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(609, 303);
            label4.Name = "label4";
            label4.Size = new Size(61, 18);
            label4.TabIndex = 5;
            label4.Text = "horario:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(586, 367);
            label5.Name = "label5";
            label5.Size = new Size(84, 18);
            label5.TabIndex = 6;
            label5.Text = "Descriçao:";
            // 
            // btnInserir
            // 
            btnInserir.Location = new Point(82, 443);
            btnInserir.Name = "btnInserir";
            btnInserir.Size = new Size(75, 23);
            btnInserir.TabIndex = 7;
            btnInserir.Text = "Inserir";
            btnInserir.UseVisualStyleBackColor = true;
            btnInserir.Click += btnInserir_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(410, 443);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(75, 23);
            btnEditar.TabIndex = 8;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(733, 443);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 23);
            btnExcluir.TabIndex = 9;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // txtID
            // 
            txtID.Location = new Point(59, 62);
            txtID.Name = "txtID";
            txtID.ReadOnly = true;
            txtID.Size = new Size(53, 26);
            txtID.TabIndex = 10;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(143, 296);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(188, 26);
            txtNome.TabIndex = 11;
            // 
            // txtDescriçao
            // 
            txtDescriçao.Location = new Point(676, 364);
            txtDescriçao.Multiline = true;
            txtDescriçao.Name = "txtDescriçao";
            txtDescriçao.Size = new Size(159, 67);
            txtDescriçao.TabIndex = 14;
            // 
            // dtpData
            // 
            dtpData.CustomFormat = "dd/MM/yyyy";
            dtpData.Format = DateTimePickerFormat.Custom;
            dtpData.Location = new Point(143, 365);
            dtpData.Name = "dtpData";
            dtpData.Size = new Size(125, 26);
            dtpData.TabIndex = 15;
            // 
            // dtpHorario
            // 
            dtpHorario.CustomFormat = "HH:mm";
            dtpHorario.Format = DateTimePickerFormat.Custom;
            dtpHorario.Location = new Point(676, 298);
            dtpHorario.Name = "dtpHorario";
            dtpHorario.RightToLeft = RightToLeft.No;
            dtpHorario.ShowUpDown = true;
            dtpHorario.Size = new Size(72, 26);
            dtpHorario.TabIndex = 16;
            dtpHorario.Value = new DateTime(2025, 6, 16, 21, 32, 0, 0);
            // 
            // btnDeslogar
            // 
            btnDeslogar.Location = new Point(813, 4);
            btnDeslogar.Name = "btnDeslogar";
            btnDeslogar.Size = new Size(98, 33);
            btnDeslogar.TabIndex = 17;
            btnDeslogar.Text = "Deslogar";
            btnDeslogar.UseVisualStyleBackColor = true;
            btnDeslogar.Click += btnDeslogar_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(296, 70);
            label6.Name = "label6";
            label6.Size = new Size(108, 18);
            label6.TabIndex = 19;
            label6.Text = "filtrar por data:";
            // 
            // dateTimeFiltrar
            // 
            dateTimeFiltrar.CustomFormat = "dd/MM/yyyy";
            dateTimeFiltrar.Format = DateTimePickerFormat.Custom;
            dateTimeFiltrar.Location = new Point(410, 64);
            dateTimeFiltrar.Name = "dateTimeFiltrar";
            dateTimeFiltrar.Size = new Size(125, 26);
            dateTimeFiltrar.TabIndex = 20;
            dateTimeFiltrar.ValueChanged += dateTimeFiltrar_ValueChanged;
            // 
            // tela_principal
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(923, 513);
            Controls.Add(dateTimeFiltrar);
            Controls.Add(label6);
            Controls.Add(btnDeslogar);
            Controls.Add(dtpHorario);
            Controls.Add(dtpData);
            Controls.Add(txtDescriçao);
            Controls.Add(txtNome);
            Controls.Add(txtID);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnInserir);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(datagridTarefas);
            Controls.Add(lblusuario);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "tela_principal";
            StartPosition = FormStartPosition.CenterParent;
            Text = "tela_principal";
            FormClosed += tela_principal_FormClosed;
            Load += tela_principal_Load;
            ((System.ComponentModel.ISupportInitialize)datagridTarefas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblusuario;
        private DataGridView datagridTarefas;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnInserir;
        private Button btnEditar;
        private Button btnExcluir;
        private TextBox txtID;
        private TextBox txtNome;
        private TextBox txtDescriçao;
        private DateTimePicker dtpData;
        private DateTimePicker dtpHorario;
        private Button btnDeslogar;
        private Label label6;
        private DateTimePicker dateTimeFiltrar;
    }
}