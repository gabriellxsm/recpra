﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace recuperaçao
{
    class ConexaoDb
    {
        private string conexao = "Server=localhost; Database=appcrud; Uid=root; Pwd='';";

        public MySqlConnection Conectar()
        {
            MySqlConnection conn = new MySqlConnection(conexao);
            try
            {
                conn.Open();
                Console.WriteLine("Conexão estabelecida com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao conectar: " + ex.Message);
            }
            return conn;
        }
    }
}
