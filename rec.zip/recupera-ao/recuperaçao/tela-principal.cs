﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace recuperaçao
{
    public partial class tela_principal : Form
    {
        private int idUsuario;
        private string nomeUsuario;
        public tela_principal(int idUsuario, string nomeUsuario)
        {
            usuarioscs usuario = new usuarioscs();
            tarefas tarefa = new tarefas();
            InitializeComponent();
            this.idUsuario = idUsuario;
            this.nomeUsuario = nomeUsuario;

            lblusuario.Text = "Usuário: " + nomeUsuario;
            tarefa.IdUsuario = idUsuario;

            datagridTarefas.DataSource = tarefa.listar(idUsuario);

        }
        private void atualizarDataGrid()
        {
            try
            {
                tarefas tarefa = new tarefas();
                DataTable dt = tarefa.listar(idUsuario);
                tarefa.IdUsuario = idUsuario;
                datagridTarefas.DataSource = tarefa.listar(idUsuario);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar a lista de tarefas: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtNome.Text.Equals("") && !dtpData.Text.Equals("") && !dtpHorario.Text.Equals("") && !txtDescriçao.Text.Equals(""))
                {
                    tarefas tarefa = new tarefas();
                    tarefa.Nome = txtNome.Text;
                    tarefa.Descricao = txtDescriçao.Text;
                    tarefa.Data = dtpData.Value;
                    tarefa.Hora = dtpHorario.Value;
                    tarefa.IdUsuario = idUsuario;

                    tarefa.InserirTarefa();
                    MessageBox.Show("Tarefa inserida com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    atualizarDataGrid(); // Atualiza o DataGridView após a inserção
                    txtDescriçao.Clear();
                    txtNome.Clear();
                    dtpData.Value = DateTime.Now;
                    dtpHorario.Value = DateTime.Now;
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir tarefa: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tela_principal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void tela_principal_Load(object sender, EventArgs e)
        {
            try
            {
                tarefas tarefa = new tarefas();
                tarefa.IdUsuario = idUsuario;
                atualizarDataGrid();
                datagridTarefas.DataSource = tarefa.listar(idUsuario);
                datagridTarefas.AllowUserToAddRows = false;
                datagridTarefas.ReadOnly = true;
                datagridTarefas.Columns["Id_tarefas"].Visible = false; // Oculta a coluna de ID
                datagridTarefas.Columns["Id_usuario"].Visible = false; // Oculta a coluna de ID do usuário
                datagridTarefas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Ajusta o tamanho das colunas
                datagridTarefas.AutoResizeColumns(); // Redimensiona as colunas para caber o conteúdo
                datagridTarefas.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // Permite seleção de linha inteira
                datagridTarefas.MultiSelect = false; // Desabilita a seleção múltipla
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a tela principal: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtDescriçao.Text.Equals("") && !txtNome.Text.Equals("") && !dtpData.Text.Equals("") && !dtpHorario.Text.Equals(""))
                {
                    tarefas tarefa = new tarefas();
                    tarefa.Id = Convert.ToInt32(txtID.Text);
                    tarefa.Nome = txtNome.Text;
                    tarefa.Descricao = txtDescriçao.Text;
                    tarefa.Data = dtpData.Value;
                    tarefa.Hora = dtpHorario.Value;
                    tarefa.IdUsuario = idUsuario;

                    tarefa.atualizar();
                    MessageBox.Show("Tarefa editada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    atualizarDataGrid(); // Atualiza o DataGridView após a edição
                    txtDescriçao.Clear();
                    txtNome.Clear();
                    dtpData.Value = DateTime.Now;
                    dtpHorario.Value = DateTime.Now;
                    datagridTarefas.ClearSelection(); // Limpa a seleção do DataGridView
                    datagridTarefas.ClearSelection();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar tarefa: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int idTarefaSelecionada = 0;
        private void datagridTarefas_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = datagridTarefas.Rows[e.RowIndex];
                    txtID.Text = row.Cells["Id_tarefas"].Value.ToString();
                    txtNome.Text = row.Cells["nome"].Value.ToString();
                    txtDescriçao.Text = row.Cells["descriçao"].Value.ToString();
                    dtpData.Value = Convert.ToDateTime(row.Cells["data_entrega"].Value);
                    TimeSpan hora = (TimeSpan)row.Cells["horario"].Value;

                    dtpHorario.Value = dtpData.Value.Date + hora; // Combina a data com a hora
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar a tarefa: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int idtarefaexcluido = 0;
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (idtarefaexcluido >= 0)
                {
                    tarefas tarefa = new tarefas();
                    var resultado = MessageBox.Show("Deseja realmente excluir a tarefa selecionada?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (resultado == DialogResult.Yes)
                    {
                        tarefa.Id = Convert.ToInt32(txtID.Text);
                        tarefa.IdUsuario = idUsuario; // Certifique-se de que o ID do usuário está definido
                        tarefa.excluir();
                        MessageBox.Show("Tarefa excluída com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        atualizarDataGrid(); // Atualiza o DataGridView após a exclusão
                        txtDescriçao.Clear();
                        txtNome.Clear();
                        dtpData.Value = DateTime.Now;
                        dtpHorario.Value = DateTime.Now;
                        datagridTarefas.ClearSelection(); // Limpa a seleção do DataGridView
                    }
                    else
                    {
                        if (resultado == DialogResult.No)
                        {
                            MessageBox.Show("Exclusão cancelada.", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            atualizarDataGrid(); // Atualiza o DataGridView para refletir que a tarefa não foi excluída
                            txtDescriçao.Clear();
                            txtNome.Clear();
                            dtpData.Value = DateTime.Now;
                            dtpHorario.Value = DateTime.Now;
                            datagridTarefas.ClearSelection(); // Limpa a seleção do DataGridView
                            txtID.Clear(); // Limpa o campo de ID
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Nenhuma tarefa selecionada para exclusão.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir tarefa: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeslogar_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.Show();
            this.Hide(); // Esconde a tela principal
        }

        private void dateTimeFiltrar_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
